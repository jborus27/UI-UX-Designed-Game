var numsAndLetters = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
var level = 1;
var limit = -2;
var textAreas = [];
var displayedCharacters = [];

for (var i = 1; i <= 16; i++) textAreas.push("text_area" + i);

function getRandomCharacter() {
    return numsAndLetters[Math.floor(Math.random() * numsAndLetters.length)];
}

function displayRandomCharacter() {
    var randomTextAreaIndex = Math.floor(Math.random() * textAreas.length);
    var randomCharacter = getRandomCharacter();
    displayedCharacters.push(randomCharacter);
    textAreas.forEach(function(area, index) {
        if (index === randomTextAreaIndex) {
            setText(area, randomCharacter);
            showElement(area);
        } else hideElement(area);
    });
    setLimit();
}

var intervalId;

onEvent("instructionPlayButton", "click", function() {
    setScreen("randCharacterScreen");
    displayRandomCharacter();
});

onEvent("Letsgo", "click", function() {
    setScreen("instructionScreen");
    setLimit();
    levelIncrease();
});

function setLimit() {
    if (++limit === 6) {
        clearInterval(intervalId);
        setScreen("answerScreen");
        limit = -2;
        for (var i = 1; i <= 6; i++) setText("text_input" + i, "");
    }
}

onEvent("submit_Button", "click", function() {
    var userOrder = [];
    for (var i = 1; i <= 6; i++) userOrder.push(getText("text_input" + i).toUpperCase());
    if (JSON.stringify(userOrder) === JSON.stringify(displayedCharacters.slice(0, 6))) setScreen("correctScreen");
    else setScreen("incorrectScreen");
});

onEvent("Return_to_start", "click", function() {
    setScreen("openingScreen");
});

onEvent("Level2Button", "click", function() {
    setScreen("randCharacterScreen");
    limit = 0;
    level++;
    intervalId = setInterval(displayRandomCharacter, 2000);
});

function levelIncrease() {
    intervalId = setInterval(displayRandomCharacter, 2000);
}
